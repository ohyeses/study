package kr.smhrd.myapp;
/*
  /memberList.do   -> MemberListController
  /memberInsert.do -> MemberInsertController 
        |                      |  
  /memberList.do   -> MemberController -> Method Mapping
  /memberInsert.do -> MemberController -> Method Mapping
*
*/

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.smhrd.mapper.MemberMapper;
import kr.smhrd.model.MemberVO;

@Controller
public class MemberController {

	@Resource(name="memberMapper")
	private MemberMapper dao;	
	// HandlerMapping(X)
	@RequestMapping("/memberList.do")
	public String memberList(Model model) {
		
		List<MemberVO> list=dao.memberList();	
		model.addAttribute("list", list);
		
		return "memberList"; // /WEB-INF/views/memberList.jsp <--- ${list}
	}
	
	@RequestMapping("/memberInsert.do")
	public String memberInsert(MemberVO vo) {
		dao.memberInsert(vo);	
		return "redirect:/memberList.do";
	}
	
	@RequestMapping("/memberDelete.do")
	public String memberDelete(int num) {
		dao.memberDelete(num);		
		return "redirect:/memberList.do";
	}
	
	@RequestMapping("/memberUpdate.do")
	public String memberUpdate(MemberVO vo) {
		dao.memberUpdate(vo);		
		return "redirect:/memberList.do";
	}
	
	@RequestMapping("/memberContent.do")
	public String memberContent(int num, Model model) {
		MemberVO vo=dao.memberContent(num);
		model.addAttribute("vo", vo);
		return "memberContent";
	}
	
	@RequestMapping("/memberRegister.do")
	public String memberRegister() {
				
		return "memberRegister";
	}
}
