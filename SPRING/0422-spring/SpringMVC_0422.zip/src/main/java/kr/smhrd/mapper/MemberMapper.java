package kr.smhrd.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.smhrd.model.MemberVO;

@Mapper
public interface MemberMapper {
	   public List<MemberVO> memberList();
	   public int memberInsert(MemberVO vo);
	   public int memberDelete(int num);
	   public int memberUpdate(MemberVO vo);
	   public MemberVO memberContent(int num);
}
