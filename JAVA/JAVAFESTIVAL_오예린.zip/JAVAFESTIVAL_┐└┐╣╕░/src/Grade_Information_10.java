
public class Grade_Information_10 {

	public static void main(String[] args) {
		String score = "A,A,B,C,D,A,C,D,D,D,F";
		int cntA, cntB, cntC, cntD, cntF;
		System.out.println(score.charAt(2));
		
		
		for(int i=0;i<12; i++) {
			if(score.charAt(i) == "A") {
				cntA++;
			}
				
		}
	}

}
