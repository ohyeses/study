
public class test_while {

	public static void main(String[] args) {

		System.out.println(reverseStr("ZABcdefEDFaZC"));
	}
	
	
	public static String reverseStr(String string) {
		String result= "";
		char[] strArr=new char[string.length()];
		for(int i=0;i<string.length();i++) {
			strArr[i]=string.charAt(i);
		}
		//char[] strArr= string.toCharArray();
		char mid=' ';//�����ϳ� ���� ���鰪//temp�� ����
		//���� �����ϴ� ��
		for(int i=0; i<strArr.length;i++) {
			for(int j=i;j<strArr.length;j++) {
				if(strArr[i]>strArr[j]) {
					mid=strArr[j];
					strArr[j]=strArr[i];
					strArr[i]=mid;
				}
			}
		}
		
		//��º�
		for(int i=0; i<strArr.length;i++) {
			result+=strArr[i];
		}
		
		return result;
	}

	
}
