import java.util.Scanner;

public class N_fibo_17 {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	
	System.out.print("input N : ");
	int N = sc.nextInt();
	
	for (int i = 1; i<=N; i++) {
		System.out.println(fibo(i));
		 
	}
	
	}

	public static void fibo(int i) {
		int cnt = 0;
		for(int a= 0; a<i; a++) {
			cnt++;
			System.out.print((i + cnt));
		}
	}

}
