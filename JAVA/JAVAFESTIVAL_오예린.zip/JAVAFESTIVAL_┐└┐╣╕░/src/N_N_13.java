import java.util.Scanner;

public class N_N_13 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("N*N �迭 �Է±� N�� �Է�>> ");
		int sizeArr= sc.nextInt();
		int[][] Arr=new int[sizeArr][sizeArr];
		int cnt=1;
		for(int i=0 ; i<Arr.length;i++) {
			for(int j=0; j<Arr[i].length;j++) {
				Arr[j][i]=cnt;
				cnt++;
			}
		}
		for(int i=0 ; i<Arr.length;i++) {
			for(int j=0; j<Arr[i].length;j++) {
				System.out.print(Arr[j][i]+"\t");
			}
			System.out.println();
		}
		
		
	}

}
