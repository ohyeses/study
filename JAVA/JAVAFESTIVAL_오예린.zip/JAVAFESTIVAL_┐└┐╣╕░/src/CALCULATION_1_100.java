import java.util.Scanner;

// 1-2+3-4+5-6+...+99-100

public class CALCULATION_1_100 {

public static int sum(int n)
{
	if (n%2==0)
		return (-(n/2));
	else
		return ((n+1)/2);
}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
// ���� -2 (while)
		int n = 0; // �� ��
		int h = 0; // ��

		while (n < 100) {
			n += 1;
			if (n % 2 == 1) {
				h = h + n;
			} else {
				h = h - n;
			}
		}
		System.out.println(h);

// ���� -3 (for)
		int even1 = 0; // ¦���� ��
		int odd1 = 0; // Ȧ���� ��
		for (int a = 1; a <= 100; a++) {
			if (a % 2 == 0) {
				even1 = even1 + a;
			} else if (a % 2 != 0) {
				odd1 = odd1 + a;
			}

			System.out.println(odd1 - even1);
		}

// ���� -4
		boolean flag = false;
		int hap = 0;
		for (int x = 1; x <= 100; x++) {
			if (flag) {
				hap = hap - x;
				flag = false;
			} else {
				hap = hap + x;
				flag = true;
			}
		}
		System.out.println(hap);

// ���� -5
// 1-2+3-4+5-6������N
		int N;
		System.out.print("N�� ���� �Է��Ͻʽÿ� :");
		N = sc.nextInt();
		
		System.out.println("�հ� : "+ sum(N));
	}

}
