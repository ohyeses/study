
public class reverseStr_test {

	public static void main(String[] args) {
		System.out.println(reverseStr("ZAbcdVefEg"));

	}

	public static String reverseStr(String input) {
		int[] alpha = new int[input.length()];

		for (int i = 0; i < input.length(); i++) {
			alpha[i] = (int) input.charAt(i);
		}
		
	      for (int j = 1; j < alpha.length; j++) {
	          for (int i = 0; i < alpha.length-1; i++) {
	             if (alpha[i] > alpha[i + 1]) {
	                int temp = alpha[i];
	                alpha[i] = alpha[i + 1];
	                alpha[i + 1] = temp;
	             }
	          }
	       }
		
		String result = " ";
		for (int i = 0; i < input.length(); i++) {
			result += (char) alpha[i];
		}
		return result;
	}

}
