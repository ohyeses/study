import java.util.Scanner;

public class TRIANGLE {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("�� ���� : ");
		
		int N = sc.nextInt();
		for (int i=1; i<=N; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		
		//���� 2 ���ﰢ��
		for(int a=N; a>=1; a--) {
			for(int b=1; a>=b; b++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		
	}

}
