// 1차원 점들이 주어졌을 때,
// 그 중 가장 거리가 짧은 점(index)들을 출력하시오


























/*

public class Q11 {
 
    public static void main(String[] args) {
 
        int[] point = { 92, 32, 52, 9, 81, 2, 68 };
        int min = Math.abs(point[0] - point[1]);
 
        String result = null;
 
        for (int i = 0; i < point.length; i++) {
 
            for (int j = 1; j < point.length; j++) {
 
                if (i != j) {
 
                    if (min > Math.abs(point[i] - point[j])) {
                        min = Math.abs(point[i] - point[j]);
 
                        result = "[" + point[i] + ", " + point[j] + "]";
                    }
 
                }
 
            }
 
        }
 
        System.out.println(result);
    }
 
}

*/






