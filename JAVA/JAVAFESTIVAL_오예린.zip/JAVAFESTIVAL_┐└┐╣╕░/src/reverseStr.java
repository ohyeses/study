
public class reverseStr {

	public static void main(String[] args) {
		 System.out.println(reverseStr("ZAbcdVefEg"));
	   }

	   public static String reverseStr(String input) {
	      char[] alpha = new char[input.length()]; //����

	      for (int i = 0; i < input.length(); i++) {
	         alpha[i] = input.charAt(i);
	      }
	      for (int j = 0; j < alpha.length; j++) {
	         for (int i = 0; i < alpha.length; i++) {
	            if (alpha[j] > alpha[i]) { //����
	               char temp = alpha[i]; //����
	               alpha[i] = alpha[j]; //����
	               alpha[j] = temp; //����
	            }
	         }
	      }
	         String result = " ";
	         for (int i = 0; i < input.length(); i++) {
	            result += (char) alpha[i];
	         }
	         return result;

	}

}
