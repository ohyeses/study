import java.util.Scanner;

public class CHANGE {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int thousand_won;
		int five_thousand_won;
		int ten_thousand_won;
		int five_hundred_won;
		int hundred_won;
		
		System.out.print("�ѱݾ� �Է� : ");
		int change = sc.nextInt();
		
		ten_thousand_won = change/10000;
		five_thousand_won = (change%10000)/1000;
		//thousand_won = change/1000 - ten_thousand_won*10;
		thousand_won = (change%5000)/1000;
		
		five_hundred_won = (change%1000)/500;
		hundred_won = (change%500)/100;
		
		System.out.println("�ܵ� : "+ change+ "��");
		System.out.println("10000�� : " + ten_thousand_won +"��");
		System.out.println("5000�� : " + five_thousand_won +"��");
		System.out.println("1000�� : " + thousand_won +"��");
		System.out.println("500�� : " + five_hundred_won +"��");
		System.out.println("100�� : " + hundred_won +"��");
		
		
	}

}
