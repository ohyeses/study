import java.util.Scanner;

public class ROUND {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("���� �Է� : ");
		int num = sc.nextInt();
		int result = 1;
		
		int round_num = num%10;
		if (round_num>=5) {
			result = ((num/10)*10)+10;
		}else {
			result = (num/10)*10;
		}
		
		System.out.println("�ݿø� �� : " + result);
	}

}
